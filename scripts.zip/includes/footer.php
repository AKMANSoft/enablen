<link rel="stylesheet" href="../css/components/footer.css">

<footer>
    <div class="middle_section">
        <div class="section_left">
            <a href="/" class="logo_container">
                <custom-svg src="./images/logo.svg" width="226" height="90" alt="" class="logo"></custom-svg>
            </a>
            <div class="contact_info">
                <div class="contact_item">
                    <i class="bi bi-telephone"></i>
                    <p class="sm">(07) 4766 3626</p>
                </div>
                <div class="contact_item">
                    <i class="bi bi-envelope"></i>
                    <p class="sm">admin@enablen.com.au</p>
                </div>
                <div class="contact_item">
                    <i class="bi bi-geo-alt"></i>
                    <p class="sm">255 Charters Towers Rd, Mysterton QLD 4812</p>
                </div>
            </div>
        </div>
        <div class="section_right">
            <div id="footer_links_container" class="links_section">
                <p id="footer_links_container_heading" class="heading strong text-black">LINKS <i class="bi bi-caret-down-fill"></i></p>
                <div class="links">
                    <a  href="/">Home</a>
                    <a href="/blogs.php">Articles</a>
                    <a href="/about_us.php">About us</a>
                </div>
            </div>
            <div id="footer_links_container" class="links_section">
                <p id="footer_links_container_heading" class="heading strong text-black">OUR SOLUTIONS <i class="bi bi-caret-down-fill"></i></p>
                <div class="links">
                    <a href="/grant_writing.php">Grant Writing</a>
                    <a href="/web_development.php">Website Development</a>
                    <a href="/eLearning.php">E-learning</a>
                </div>
            </div>
            <div id="footer_links_container" class="links_section">
                <p id="footer_links_container_heading" class="heading strong text-black">RESOURCES <i class="bi bi-caret-down-fill"></i></p>
                <div class="links">
                    <a href="/our_impact.php">Our Impact</a>
                    <a href="/privacy_policy.php">Privacy Policy</a>
                    <a href="/terms_and_conditions.php">Terms of use</a>
                </div>
            </div>
        </div>
    </div>
    <span class="divider mt-60"></span>
    <div class="bottom_section">
        <p class="xsm">Copyright © 2022 Enablen Pty Ltd. All Rights Reserved</p>
        <div class="social_icons">
            <a href="#">
                <img src="./images/facebook.svg" width="30" height="30" alt="" class="social_icon">
            </a>
            <a href="#">
                <img src="./images/linkedin.svg" width="30" height="30" alt="" class="social_icon">
            </a>
            <a href="#">
                <img src="./images/instagram.svg" width="30" height="30" alt="" class="social_icon">
            </a>
        </div>
        <div class="other_info">
            <img src="../images/qassure_logo.svg" width="80" height="37" alt="" class="qassure_logo">
            <p class="xsm">QAssure No. 23444</p>
            <p class="xsm">ABN 72 647 388 636</p>
        </div>
    </div>
</footer>
<script src="/scripts/components/footer.js"></script>