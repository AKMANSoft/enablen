<link rel="stylesheet" href="../css/components/cta_section.css">
<div class="cta_section">
    <div class="content">
        <div class="section_left">
            <h3 class="heading text-white"><?php echo $upper_section_heading ?></h3>
            <p class="desc text-white-80"><?php echo $upper_section_description ?></p>
        </div>
        <div class="section_right">
            <a href="" class="btn filled">Book A Call</a>
        </div>
    </div>
</div>