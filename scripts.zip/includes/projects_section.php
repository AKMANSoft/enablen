<link rel="stylesheet" href="../css/components/projects_section.css">
<?php include("./includes/project_popup_component.php") ?>
<section class="projects_section">
    <h2 class="heading">Projects Delivered</h2>
    <div class="projects_container">
        <div class="projects">
            <div class="project_item">
                <img src="./images/product.png" width="346" height="280" alt="">
                <div class="project_info">
                    <h4 class="name text-black">Lorem ipsum dolor sconsec it</h4>
                    <p class="desc">Lorem ipsum dolor sit amet, consectetur adipiscing elitor sit ameor sit ame...
                    </p>
                    <span class="divider mt-5"></span>
                    <strong>Grant Writing</strong>
                </div>
            </div>
            <div class="project_item">
                <img src="./images/product.png" width="346" height="280" alt="">
                <div class="project_info">
                    <h4 class="name text-black">Lorem ipsum dolor sconsec it</h4>
                    <p class="desc">Lorem ipsum dolor sit amet, consectetur adipiscing elitor sit ameor sit ame...</p>
                    <span class="divider mt-5"></span>
                    <strong>Web Development</strong>
                </div>
            </div>
            <div class="project_item">
                <img src="./images/product.png" width="346" height="280" alt="">
                <div class="project_info">
                    <h4 class="name text-black">Lorem ipsum dolor sconsec it</h4>
                    <p class="desc">Lorem ipsum dolor sit amet, consectetur adipiscing elitor sit ameor sit ame...</p>
                    <span class="divider mt-5"></span>
                    <strong>E Learning Service</strong>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="../scripts/components/projects_section.js"></script>